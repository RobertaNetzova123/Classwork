package org.elsys.part1;

import java.util.LinkedList;
import java.util.List;

public class BallContainer {

	LinkedList<Ball> list = new LinkedList<Ball>(); 
	
	public BallContainer() {
	}

	/**
	 * Adds a ball to the container.
	 * 
	 * @param b
	 *            the Ball to be added
	 * @return true if b was successfully added
	 *
	 */
	public boolean add(Ball b) {
		if(list.add(b)) {
			return true;
		}
		
		return false;
	}

	/**
	 * Removes a ball from the container.
	 * 
	 * @param b
	 *            the Ball to be removed
	 * @return true if b was present in the collection
	 */
	public boolean remove(Ball b) {
		if(list.remove(b)) {
			return true;
		}
		return false;
	}

	/**
	 * Returns the sum of the volumes of all balls in the container.
	 * 
	 * @return
	 */
	public double getVolume() {
		double sum = 0.0;
		for(Ball b : list) {
			sum += b.getVolume();
		}
		return sum;
	}

	/**
	 * Returns the total count of balls in the container.
	 * 
	 * @return
	 */
	public int size() {
		return list.size();
	}

	/**
	 * Removes all balls from the container.
	 */
	public void clear() {
		list.clear();
	}

	/**
	 * Checks whether a Ball is present in the container.
	 * 
	 * @param b
	 *            the Ball to check
	 * @return true if b is present
	 */
	public boolean contains(Ball b) {
		
		if (list.contains(b)) {
			return true;
		}
		return false;
	}

	
}