package org.elsys.part1;

public class Ball {

	double volume;
	Color color;

	public Ball(double volume, Color color) {
		this.volume = volume;
		this.color = color;
	}

	public Ball(double volume) {
		this.volume = volume;
		this.color = Color.WHITE;
	}

	public double getVolume() {
		return this.volume;
	}

	public Color getColor() {
		return this.color;
	}

	public void setVolume(double volume) {
		this.volume = volume;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Ball other = (Ball) obj;
		if (color != other.color)
			return false;
		if (Double.doubleToLongBits(volume) != Double.doubleToLongBits(other.volume))
			return false;
		return true;
	}
	
	
}