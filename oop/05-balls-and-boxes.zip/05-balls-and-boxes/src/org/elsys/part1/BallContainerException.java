package org.elsys.part1;

public class BallContainerException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -348838159147744513L;

}
