package org.elsys.part1;

import java.util.Iterator;

public class Box extends BallContainer {

	public Box(double capacity) {
	}

	public Iterator<Ball> getBallsFromSmallest() {
		return null;
	}

}